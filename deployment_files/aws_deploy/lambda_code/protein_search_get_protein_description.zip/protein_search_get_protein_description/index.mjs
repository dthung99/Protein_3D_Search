import { Client } from 'pg';

const client = new Client({
    host: "seal-idea-db.cp62semw4zd8.eu-west-2.rds.amazonaws.com",
    user: "dthung99",
    password: "dangthehung107",
    database: sealidea_db,
    port: 5432,
    ssl: {
        rejectUnauthorized: false
    }
});

client.connect()
    .then(() => console.log('Connected to the database'))
    .catch(err => console.error('Connection error', err.stack))
    .finally(() => client.end());

export const handler = async (event) => {
    // TODO implement
    const response = {
        statusCode: 200,
        body: JSON.stringify('Hello from Lambda!'),
    };
    return response;
};
